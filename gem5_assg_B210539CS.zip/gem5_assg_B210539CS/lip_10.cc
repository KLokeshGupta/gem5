#include "mem/cache/replacement_policies/lip_10.hh"

#include <memory>

#include "params/LIP10RP.hh"
#include "sim/cur_tick.hh"

namespace gem5
{

namespace replacement_policy
{

LIP10::LIP10(const Params &p)
    : LRU(p)
{
}

void
LIP10::reset(const std::shared_ptr<ReplacementData>& replacement_data) const
{
    auto lru_data = std::static_pointer_cast<LRUReplData>(replacement_data);

    if (maxHeap.size() < 10) {
        // Add the current timestamp to maxHeap
        maxHeap.push_back(curTick());
        lru_data->lastTouchTick = curTick();
    } else {
        // Find the maximum element and replace it if needed
        auto max_it = std::max_element(maxHeap.begin(), maxHeap.end());
        lru_data->lastTouchTick = *max_it; // Approximation of 10th position
        *max_it = curTick(); // Replace the maximum element with the new timestamp
    }
}


void
LIP10::invalidate(const std::shared_ptr<ReplacementData>& replacement_data)
{
    // Reset last touch timestamp
    std::static_pointer_cast<LRUReplData>(
        replacement_data)->lastTouchTick = Tick(0);

}

void
LIP10::touch(const std::shared_ptr<ReplacementData>& replacement_data) const
{
    // Update last touch timestamp (same as LRU behavior)
    std::static_pointer_cast<LRUReplData>(
        replacement_data)->lastTouchTick = curTick();
}


ReplaceableEntry*
LIP10::getVictim(const ReplacementCandidates& candidates) const
{
    // There must be at least one replacement candidate
    assert(candidates.size() > 0);

    // Find the candidate with the smallest lastTouchTick (LRU behavior)
    ReplaceableEntry* victim = candidates[0];
    Tick oldest_tick = curTick(); // Start with the current tick

    for (const auto& candidate : candidates) {
        auto lru_data = std::static_pointer_cast<LRUReplData>(candidate->replacementData);

        // Update the victim if the current candidate is older
        if (lru_data->lastTouchTick < oldest_tick) {
            oldest_tick = lru_data->lastTouchTick;
            victim = candidate;
        }

        // Update maxHeap for maintaining up to 10 most recent entries
        if (maxHeap.size() < 10) {
            maxHeap.push_back(lru_data->lastTouchTick);
        } else {
            auto max_it = std::max_element(maxHeap.begin(), maxHeap.end());
            if (*max_it > lru_data->lastTouchTick) {
                *max_it = lru_data->lastTouchTick; // Replace the maximum element
            }
        }
    }

    return victim;
}


} // namespace replacement_policy
} // namespace gem5
