build/X86/gem5.opt -d stats/assg3/bzip2/lru \
configs/deprecated/example/se.py \
--cpu-type=DerivO3CPU --sys-clock=3GHz \
--caches --l1i_size=32kB --l1d_size=32kB \
--l2cache --l2_size=256kB --l2-hwp-type=BOPPrefetcher \
--bp-type TAGE_SC_L_8KB \
--mem-size=4GB --mem-type=DDR3_1600_8x8 \
-W 50000000 -I 100000000 \
--standard-switch 50000000 \
-c /home/lokelinux/gem5/gem5/benchspec/CPU2006/401.bzip2/exe/bzip2_base.gcc43-64bit \
-o "/home/lokelinux/gem5/gem5/benchspec/CPU2006/401.bzip2/data/ref/input/input.source 280"

build/X86/gem5.opt -d stats/assg3/lbm/lru \
configs/deprecated/example/se.py \
--cpu-type=DerivO3CPU --sys-clock=3GHz \
--caches --l1i_size=32kB --l1d_size=32kB \
--l2cache --l2_size=256kB --l2-hwp-type=BOPPrefetcher \
--bp-type TAGE_SC_L_8KB \
--mem-size=4GB --mem-type=DDR3_1600_8x8 \
-W 50000000 --standard-switch 50000000 \
-I 50000000 \
-c /home/lokelinux/gem5/gem5//benchspec/CPU2006/470.lbm/exe/lbm_base.gcc43-64bit \
-o "300 /home/lokelinux/gem5/gem5/benchspec/CPU2006/470.lbm/data/ref/input/output.dat 0 0 /home/lokelinux/gem5/gem5/benchspec/CPU2006/470.lbm/data/ref/input/100_100_130_ldc.of"

build/X86/gem5.opt -d stats/assg3/namd/lru \
configs/deprecated/example/se.py \
--cpu-type=DerivO3CPU --sys-clock=3GHz \
--caches --l1i_size=32kB --l1d_size=32kB \
--l2cache --l2_size=256kB --l2-hwp-type=BOPPrefetcher \
--bp-type TAGE_SC_L_8KB \
--mem-size=4GB --mem-type=DDR3_1600_8x8 \
-W 50000000 --standard-switch 50000000 \
-I 50000000 \
-c /home/lokelinux/gem5/gem5/benchspec/CPU2006/444.namd/exe/namd_base.gcc43-64bit \
-o "--input /home/lokelinux/gem5/gem5/benchspec/CPU2006/444.namd/data/all/input/namd.input --output /home/lokelinux/gem5/gem5/benchspec/CPU2006/444.namd/data/all/input/namd.out --iterations 38"

build/X86/gem5.opt -d stats/assg3/bzip2/lip10 \
configs/deprecated/example/se.py \
--cpu-type=DerivO3CPU --sys-clock=3GHz \
--caches --l1i_size=32kB --l1d_size=32kB \
--l2cache --l2_size=256kB --l2-hwp-type=BOPPrefetcher \
--bp-type TAGE_SC_L_8KB \
--mem-size=4GB --mem-type=DDR3_1600_8x8 \
-W 50000000 -I 100000000 \
--standard-switch 50000000 \
-c /home/lokelinux/gem5/gem5/benchspec/CPU2006/401.bzip2/exe/bzip2_base.gcc43-64bit \
-o "/home/lokelinux/gem5/gem5/benchspec/CPU2006/401.bzip2/data/ref/input/input.source 280"

build/X86/gem5.opt -d stats/assg3/lbm/lip10 \
configs/deprecated/example/se.py \
--cpu-type=DerivO3CPU --sys-clock=3GHz \
--caches --l1i_size=32kB --l1d_size=32kB \
--l2cache --l2_size=256kB --l2-hwp-type=BOPPrefetcher \
--bp-type TAGE_SC_L_8KB \
--mem-size=4GB --mem-type=DDR3_1600_8x8 \
-W 50000000 --standard-switch 50000000 \
-I 50000000 \
-c /home/lokelinux/gem5/gem5//benchspec/CPU2006/470.lbm/exe/lbm_base.gcc43-64bit \
-o "300 /home/lokelinux/gem5/gem5/benchspec/CPU2006/470.lbm/data/ref/input/output.dat 0 0 /home/lokelinux/gem5/gem5/benchspec/CPU2006/470.lbm/data/ref/input/100_100_130_ldc.of"

build/X86/gem5.opt -d stats/assg3/namd/lip10 \
configs/deprecated/example/se.py \
--cpu-type=DerivO3CPU --sys-clock=3GHz \
--caches --l1i_size=32kB --l1d_size=32kB \
--l2cache --l2_size=256kB --l2-hwp-type=BOPPrefetcher \
--bp-type TAGE_SC_L_8KB \
--mem-size=4GB --mem-type=DDR3_1600_8x8 \
-W 50000000 --standard-switch 50000000 \
-I 50000000 \
-c /home/lokelinux/gem5/gem5/benchspec/CPU2006/444.namd/exe/namd_base.gcc43-64bit \
-o "--input /home/lokelinux/gem5/gem5/benchspec/CPU2006/444.namd/data/all/input/namd.input --output /home/lokelinux/gem5/gem5/benchspec/CPU2006/444.namd/data/all/input/namd.out --iterations 38"